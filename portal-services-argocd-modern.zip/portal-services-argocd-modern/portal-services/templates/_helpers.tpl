{{- define "portal-service.fullname" -}}
{{- required "fullnameOverride is required" .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{- define "portal-service.selectorLabels" -}}
app.kubernetes.io/name: {{ required "app.name is required" .Values.app.name | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end }}

{{- define "portal-service.labels" -}}
{{ include "portal-service.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/part-of: "portal-services"
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
environment: {{ .Values.environment | quote }}
helm.sh/chart: "{{ .Chart.Name }}-{{ .Chart.Version }}"
{{- end }}
