# Portal Services: Helm + EKS Managed Argo CD

This starter restructures the existing `portal-services` chart so that:

- namespaces are `portal-services-dev`, `portal-services-devb`, and `portal-services-devc`;
- every service/environment combination is a separate Argo CD Application;
- Kubernetes objects follow `<service>-<environment>`;
- route paths stay service-specific, for example `email-services`;
- shared cluster resources are not owned by every application;
- Jenkins builds images and updates Git; Argo CD performs deployment.

For `email-services` in `dev`:

- Argo CD Application: `email-services-dev`
- Helm release: `email-services-dev`
- Namespace: `portal-services-dev`
- Deployment and Service: `email-services-dev`
- ConfigMap: `email-services-dev-catalina`
- Pod: `email-services-dev-<replicaset-hash>-<pod-id>`
- Route path: `/email-services`

## Validate one service

```bash
helm lint portal-services \
  -f portal-services/values/common.yaml \
  -f portal-services/values/services/email-services.yaml \
  -f portal-services/values/environments/dev.yaml \
  -f portal-services/values/overrides/dev/email-services.yaml \
  --set app.name=email-services \
  --set environment=dev \
  --set fullnameOverride=email-services-dev

helm template email-services-dev portal-services \
  --namespace portal-services-dev \
  -f portal-services/values/common.yaml \
  -f portal-services/values/services/email-services.yaml \
  -f portal-services/values/environments/dev.yaml \
  -f portal-services/values/overrides/dev/email-services.yaml \
  --set app.name=email-services \
  --set environment=dev \
  --set fullnameOverride=email-services-dev
```

Before deployment:

1. Replace `REPLACE_WITH_IMAGE_TAG`.
2. Replace EFS file-system ID placeholders.
3. Verify each `SecretProviderClass` name.
4. Copy the complete current Catalina properties content into
   `portal-services/files/catalina.properties`.
5. Confirm the `dev` Git revision in the ApplicationSet matches your branch.

Apply:

```bash
kubectl apply -f argocd/portal-services-namespaces.yaml
kubectl apply -f argocd/portal-services-project.yaml
kubectl apply -f argocd/portal-services-applicationset.yaml
```

Check generated applications:

```bash
kubectl get applications -n argocd \
  -l argocd.argoproj.io/application-set-name=portal-services
```
