# Migration map

| Current | New |
|---|---|
| `templates/configmaps/catalina.properties.yaml` | `files/catalina.properties` + `templates/configmap-catalina.yaml` |
| `templates/deployments/portal-services-deploy.yaml` | `templates/deployment.yaml` |
| `templates/services/portal-services-svc.yaml` | `templates/service.yaml` |
| `templates/volumes/portal-services-sc-pvc.yaml` | app-owned `templates/pvc.yaml`; cluster-owned StorageClasses under `platform/` |
| `email-services-values.yaml` | `values/services/email-services.yaml` |
| `portal-services-values-dev.yaml` | split across environment, service, and override files |
| `basApps[].lb_path` | `values/services/<service>.yaml` → `routing.lbPath` |
| Jenkins `helm upgrade` | Jenkins updates an immutable tag in Git; Argo CD deploys |

Do not render `metadata.namespace` in chart templates. Argo CD supplies the
destination namespace. Do not create Namespace or StorageClass objects from each
service Application.
